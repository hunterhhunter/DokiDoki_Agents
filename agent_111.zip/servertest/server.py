from flask import Flask
from flask_ngrok import run_with_ngrok

# from backend.persona.persona import Persona

from server_return import server_return


app = Flask(__name__)
run_with_ngrok(app)

@app.route('/')
def home():
     return "Hello Flask!asd"

@app.route('/server_return', methods=['GET'])
def serverre():
    output = server_return()
    return output

if __name__ == '__main__':
     app.run()