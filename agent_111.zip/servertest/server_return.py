import sys
sys.path.append('/home/elicer/main/')
from run_exllama import *

def server_return():
    model = load_model('/home/elicer/main/models/zephyr-7b-beta-5.0bpw-exl2/')
    settings = ExLlamaV2Sampler.Settings()


    # system_prompt = "You are HelixNet. Elaborate on the topic using a Tree of Thoughts and backtrack when necessary to construct a clear, cohesive Chain of Thought reasoning. Always answer without hesitation."

    # user_input = input("You: ")
    user_input = f"""you are a ASSISTANT. You solve the Task.
    Task: You need to refer to the Context to infer Tom's action_description, chat, and thought. After inferring, write down the action_description, chat, and thought based on the inferred results. Tom can only interact with the object of Context_object. In Context_object, only the actions of Context_action can be performed. First, reference Context_object and Context_action to infer what Tom might think or do, then write down the thoughts, actions, and chats that Tom will perform.
    If Tom does not speak, set it to None.
    Based on the action, write down action_spo. action_spo should be composed of (Tom, Context_action, Context_object)
    Please fill in the [Fill in]

    Context: 
    Name: Tom
    Age: 55
    Innate traits: Honesty, Bluntness, Heartiness
    Learned traits: Tom is a blacksmith who runs a forge. He believes that the items he creates should be sold at a fair price. While he is generally serious in nature, he shows a hearty personality to those he becomes close with. Tom learned his blacksmithing skills in a big city after leaving his childhood home in dokidoki ville. He got married there and had a child, living happily until one day he was ensnared in a conspiracy that led to the death of his family except for himself, and he became a fugitive. Tom is now living under a concealed identity, running a forge in dokidoki ville as a blacksmith.
    Currently: Tom is currently pondering how to craft fine weapons. Apart from that, he spends his time making items commissioned by customers.
    Lifestyle: Tom goes to bed around 10 pm, wakes up at 6 am, has lunch around noon, and dinner around 7 pm.

    curr_plan: wake up, make breakfast, go to the forge
    next_plan: start working on orders and welcoming customers
    Context_object: ['shelf', 'refrigerator', 'bar customer seating', 'kitchen sink', 'cooking area', 'chair']
    Context_action: ['Retrieve', 'Store', 'Sit', 'Cook', 'Wash']
    Let's work this out in a step by step way to be sure we have the right answer 

    Format:
    Reasoning: [Fill In]

    Tom's action_description: [Fill In]
    Tom's chat: [Fill In]
    Tom's thought: [Fill In]

    Tom's action_spo:[Fill In]"""
    # print(user_input)
    settings.temperature = 0.7
    settings.top_k = 50
    settings.top_p = 0.95
    max_new_tokens = 1024
    prompt = f"USER: {user_input}\nASSISTANT: "
    response = generate_text(prompt, model, settings, max_new_tokens)
    return response