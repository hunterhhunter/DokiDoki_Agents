import sys
import os



class Game_open:
    def __init__(self, ):
        persona=