"""

"""
import os

current_file_path = os.path.abspath(__file__)
current_file_dir = os.path.dirname(current_file_path)
os.chdir(current_file_dir)

import sys
sys.path.append('../../')

import json
import datetime

from global_methods import *

# class ConceptNode:
#     def __init__(self,
#                  node_id, node_count, type_count, node_type,
#                  s, p, o,
#                  description, embedding_key, poignancy,
#                  chat, thought):
#         self.node_id = node_id
#         self.node_count = node_count
#         self.type_count = type_count
#         self.type = node_type
        
#         self.subject = s
#         self.predicate = p
#         self.object = o

#         self.description = description
#         self.embedding_key = embedding_key
#         if chat:
#             self.chat = chat
#         if thought:
#             self.thought = thought
#         self.poignancy = poignancy

#     def spo_summary(self):
#         return (self.subject, self.predicate, self.object)


# class AssociativeMemory:
#     def __init__(self, f_saved):
#         self.id_to_node = dict()
#         self.f_saved = f_saved

#         self.seq_event = []
#         self.seq_thought = []
#         self.curr_chat = []

#         self.relationship = json.load(open(self.f_saved+ "/relationship.json"))
#         self.embeddings = json.load(open(self.f_saved + "/embeddings.json"))

#         nodes_load = json.load(open(f_saved + "/nodes.json"))
#         for count in range(len(nodes_load.keys())):
#             node_id = f"node_{str(count+1)}"
#             node_details = nodes_load[node_id]
            
#             node_count = node_details['node_count']
#             type_count = node_details["type_count"]
#             node_type = node_details["type"]

#             s = node_details["subject"]
#             p = node_details["predicate"]
#             o = node_details["object"]

#             description = node_details["description"]
#             embedding_pair = (node_details["embedding_key"], 
#                         self.embeddings[node_details["embedding_key"]])
#             curr_chat = self.curr_chat
#             thought = "thought"

#             poignancy =node_details["poignancy"]


#             if node_type == "event": 
#                 self.add_event(s, p, o, 
#                         description, embedding_pair,
#                         curr_chat, thought, poignancy)
#             elif node_type == "chat": 
#                 self.add_event(s, p, o, 
#                         description, embedding_pair,
#                         curr_chat, thought, poignancy)
#             elif node_type == "thought": 
#                 self.add_event(s, p, o, 
#                         description, embedding_pair,
#                         curr_chat, thought, poignancy)

class ConceptNode: 
  def __init__(self,
               node_id, node_count, type_count, node_type, depth,
               created, expiration, 
               s, p, o, 
               description, embedding_key, poignancy, keywords, filling): 
    self.node_id = node_id
    self.node_count = node_count
    self.type_count = type_count
    self.type = node_type # thought / event / chat
    self.depth = depth

    self.created = created
    self.expiration = expiration
    self.last_accessed = self.created

    self.subject = s
    self.predicate = p
    self.object = o

    self.description = description
    self.embedding_key = embedding_key
    self.poignancy = poignancy
    self.keywords = keywords
    self.filling = filling


  def spo_summary(self): 
    return (self.subject, self.predicate, self.object)


class AssociativeMemory: 
  def __init__(self, f_saved): 
    self.id_to_node = dict()

    self.seq_event = []
    self.seq_thought = []
    self.seq_chat = []

    self.kw_to_event = dict()
    self.kw_to_thought = dict()
    self.kw_to_chat = dict()

    self.kw_strength_event = dict()
    self.kw_strength_thought = dict()

    self.embeddings = json.load(open(f_saved + "/embeddings.json"))

    nodes_load = json.load(open(f_saved + "/nodes.json"))
    for count in range(len(nodes_load.keys())): 
      node_id = f"node_{str(count+1)}"
      node_details = nodes_load[node_id]

      node_count = node_details["node_count"]
      type_count = node_details["type_count"]
      node_type = node_details["type"]
      depth = node_details["depth"]

      created = datetime.datetime.strptime(node_details["created"], 
                                           '%Y-%m-%d %H:%M:%S')
      expiration = None
      if node_details["expiration"]: 
        expiration = datetime.datetime.strptime(node_details["expiration"],
                                                '%Y-%m-%d %H:%M:%S')

      s = node_details["subject"]
      p = node_details["predicate"]
      o = node_details["object"]

      description = node_details["description"]
      embedding_pair = (node_details["embedding_key"], 
                        self.embeddings[node_details["embedding_key"]])
      poignancy =node_details["poignancy"]
      keywords = set(node_details["keywords"])
      filling = node_details["filling"]
      
      if node_type == "event": 
        self.add_event(created, expiration, s, p, o, 
                   description, keywords, poignancy, embedding_pair, filling)
      elif node_type == "chat": 
        self.add_chat(created, expiration, s, p, o, 
                   description, keywords, poignancy, embedding_pair, filling)
      elif node_type == "thought": 
        self.add_thought(created, expiration, s, p, o, 
                   description, keywords, poignancy, embedding_pair, filling)

    kw_strength_load = json.load(open(f_saved + "/kw_strength.json"))
    if kw_strength_load["kw_strength_event"]: 
      self.kw_strength_event = kw_strength_load["kw_strength_event"]
    if kw_strength_load["kw_strength_thought"]: 
      self.kw_strength_thought = kw_strength_load["kw_strength_thought"]

    
  def save(self, out_json): 
    r = dict()
    for count in range(len(self.id_to_node.keys()), 0, -1): 
      node_id = f"node_{str(count)}"
      node = self.id_to_node[node_id]

      r[node_id] = dict()
      r[node_id]["node_count"] = node.node_count
      r[node_id]["type_count"] = node.type_count
      r[node_id]["type"] = node.type
      r[node_id]["depth"] = node.depth

      r[node_id]["created"] = node.created.strftime('%Y-%m-%d %H:%M:%S')
      r[node_id]["expiration"] = None
      if node.expiration: 
        r[node_id]["expiration"] = (node.expiration
                                        .strftime('%Y-%m-%d %H:%M:%S'))

      r[node_id]["subject"] = node.subject
      r[node_id]["predicate"] = node.predicate
      r[node_id]["object"] = node.object

      r[node_id]["description"] = node.description
      r[node_id]["embedding_key"] = node.embedding_key
      r[node_id]["poignancy"] = node.poignancy
      r[node_id]["keywords"] = list(node.keywords)
      r[node_id]["filling"] = node.filling

    with open(out_json+"/nodes.json", "w") as outfile:
      json.dump(r, outfile)

    r = dict()
    r["kw_strength_event"] = self.kw_strength_event
    r["kw_strength_thought"] = self.kw_strength_thought
    with open(out_json+"/kw_strength.json", "w") as outfile:
      json.dump(r, outfile)

    with open(out_json+"/embeddings.json", "w") as outfile:
      json.dump(self.embeddings, outfile)


  def add_event(self, created, expiration, s, p, o, 
                      description, keywords, poignancy, 
                      embedding_pair, filling):
    # Setting up the node ID and counts.
    node_count = len(self.id_to_node.keys()) + 1
    type_count = len(self.seq_event) + 1
    node_type = "event"
    node_id = f"node_{str(node_count)}"
    depth = 0

    # Node type specific clean up. 
    if "(" in description: 
      description = (" ".join(description.split()[:3]) 
                     + " " 
                     +  description.split("(")[-1][:-1])

    # Creating the <ConceptNode> object.
    node = ConceptNode(node_id, node_count, type_count, node_type, depth,
                       created, expiration, 
                       s, p, o, 
                       description, embedding_pair[0], 
                       poignancy, keywords, filling)

    # Creating various dictionary cache for fast access. 
    self.seq_event[0:0] = [node]
    keywords = [i.lower() for i in keywords]
    for kw in keywords: 
      if kw in self.kw_to_event: 
        self.kw_to_event[kw][0:0] = [node]
      else: 
        self.kw_to_event[kw] = [node]
    self.id_to_node[node_id] = node 

    # Adding in the kw_strength
    if f"{p} {o}" != "is idle":  
      for kw in keywords: 
        if kw in self.kw_strength_event: 
          self.kw_strength_event[kw] += 1
        else: 
          self.kw_strength_event[kw] = 1

    self.embeddings[embedding_pair[0]] = embedding_pair[1]

    return node


  def add_thought(self, created, expiration, s, p, o, 
                        description, keywords, poignancy, 
                        embedding_pair, filling):
    # Setting up the node ID and counts.
    node_count = len(self.id_to_node.keys()) + 1
    type_count = len(self.seq_thought) + 1
    node_type = "thought"
    node_id = f"node_{str(node_count)}"
    depth = 1 
    try: 
      if filling: 
        depth += max([self.id_to_node[i].depth for i in filling])
    except: 
      pass

    # Creating the <ConceptNode> object.
    node = ConceptNode(node_id, node_count, type_count, node_type, depth,
                       created, expiration, 
                       s, p, o, 
                       description, embedding_pair[0], poignancy, keywords, filling)

    # Creating various dictionary cache for fast access. 
    self.seq_thought[0:0] = [node]
    keywords = [i.lower() for i in keywords]
    for kw in keywords: 
      if kw in self.kw_to_thought: 
        self.kw_to_thought[kw][0:0] = [node]
      else: 
        self.kw_to_thought[kw] = [node]
    self.id_to_node[node_id] = node 

    # Adding in the kw_strength
    if f"{p} {o}" != "is idle":  
      for kw in keywords: 
        if kw in self.kw_strength_thought: 
          self.kw_strength_thought[kw] += 1
        else: 
          self.kw_strength_thought[kw] = 1

    self.embeddings[embedding_pair[0]] = embedding_pair[1]

    return node


  def add_chat(self, created, expiration, s, p, o, 
                     description, keywords, poignancy, 
                     embedding_pair, filling): 
    # Setting up the node ID and counts.
    node_count = len(self.id_to_node.keys()) + 1
    type_count = len(self.seq_chat) + 1
    node_type = "chat"
    node_id = f"node_{str(node_count)}"
    depth = 0

    # Creating the <ConceptNode> object.
    node = ConceptNode(node_id, node_count, type_count, node_type, depth,
                       created, expiration, 
                       s, p, o, 
                       description, embedding_pair[0], poignancy, keywords, filling)

    # Creating various dictionary cache for fast access. 
    self.seq_chat[0:0] = [node]
    keywords = [i.lower() for i in keywords]
    for kw in keywords: 
      if kw in self.kw_to_chat: 
        self.kw_to_chat[kw][0:0] = [node]
      else: 
        self.kw_to_chat[kw] = [node]
    self.id_to_node[node_id] = node 

    self.embeddings[embedding_pair[0]] = embedding_pair[1]
        
    return node


    def add_curr_chat(self, chat, end):
        chat_clean = f"{chat[0]}: {chat[1]}"
        self.curr_chat += [chat_clean]
        if end==True:
            self.add_chat()


    def add_chat_without_thought(self, s, p, o,
                    description, embedding_pair,
                    chat):

        node_count = len(self.id_to_node.keys()) + 1
        type_count = len(self.seq_event) + 1
        node_type = "chat"
        node_id = f"node_{str(node_count)}"

        node = ConceptNode(node_id, node_count, type_count, node_type,
                    s, p, o, 
                    description, embedding_pair[0], poignancy)
            
        # chat 의 형태는 전체 chat이 들어가야 한다.
        # [["tom", "안녕 반가워"],["horalson":"메롱"]]
        if chat is not None:
            self.chat = chat
        self.embeddings[embedding_pair[0]] = embedding_pair[1]
        
        return node


    def add_chat(self, s, p, o,
                    description, embedding_pair,
                    chat, thought, poignancy):

        node_count = len(self.id_to_node.keys()) + 1
        type_count = len(self.seq_event) + 1
        node_type = "chat"
        node_id = f"node_{str(node_count)}"

        node = ConceptNode(node_id, node_count, type_count, node_type,
                    s, p, o, 
                    description, embedding_pair[0], poignancy)
            
        # chat 의 형태는 전체 chat이 들어가야 한다.
        # [["tom", "안녕 반가워"],["horalson":"메롱"]]
        if chat is not None:
            self.chat = chat
        self.embeddings[embedding_pair[0]] = embedding_pair[1]
        
        return node


    def load_relationship(self, target_persona):
        relationship = json.load(open(self.f_saved+ "/relationship.json"))
        print(relationship)
        target_relationship = relationship[target_persona.scratch.name]
        return target_relationship


    def save_relationship(self, init_persona, target_persona):

        focal_points = [f"{target_persona.scratch.name}"]
        retrieved = new_retrieve(init_persona, target_persona.scratch.name, 50)

        all_embedding_keys = list()
        for key, val in retrieved.items():
            for i in val:
                all_embedding_keys += [i.embedding_key]
            all_embedding_key_str = ""
            for i in all_embedding_keys:
                all_embedding_key_str += f"{i}\n"
        
        summarized_relationship = run_gpt_prompt_agent_chat_summarize_relationship(
                              init_persona, target_persona,
                              all_embedding_key_str)[0]

        self.relationship['target_persona'] = summarized_relationship

        with open(out_json+"/relationship.json", "w") as outfile:
            json.dump(self.relationship, outfile)

        return None
        