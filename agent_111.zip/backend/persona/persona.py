"""
출처: https://github.com/joonspk-research/generative_agents/blob/main/reverie/backend_server/persona/persona.py

페르소나 모듈
"""


import math
import sys
import datetime
import random
sys.path.append('../')
import os
# 현재 파일의 절대 경로를 얻습니다.
current_dir = os.path.dirname(os.path.abspath(__file__))

# 상위 디렉토리의 경로를 구합니다.
parent_dir = os.path.dirname(current_dir)

# 상위 디렉토리를 sys.path에 추가합니다.
sys.path.insert(0, parent_dir)
from global_methods import *

from persona.memory_structures.spatial_memory import *
from persona.memory_structures.associative_memory import *
from persona.memory_structures.scratch import *

# from persona.cognitive_modules.perceive import *
# from persona.cognitive_modules.retrieve import *
# from persona.cognitive_modules.plan import *
# from persona.cognitive_modules.reflect import *
# from persona.cognitive_modules.execute import *
# from persona.cognitive_modules.converse import *

class Persona: 
    def __init__(self, name, folder_mem_saved=False):
        # PERSONA BASE STATE 
        # <name> is the full name of the persona. This is a unique identifier for
        # the persona within Reverie. 
        self.name = name

        # PERSONA MEMORY 
        # If there is already memory in folder_mem_saved, we load that. Otherwise,
        # we create new memory instances. 
        # <s_mem> is the persona's spatial memory. 
        f_s_mem_saved = f"{folder_mem_saved}/bootstrap_memory/spatial_memory.json"
        self.s_mem = MemoryTree(f_s_mem_saved)
        # <s_mem> is the persona's associative memory. 
        f_a_mem_saved = f"{folder_mem_saved}/bootstrap_memory/associative_memory"
        self.a_mem = AssociativeMemory(f_a_mem_saved)
        # <scratch> is the persona's scratch (short term memory) space. 
        scratch_saved = f"{folder_mem_saved}/bootstrap_memory/scratch.json"
        self.scratch = Scratch(scratch_saved)