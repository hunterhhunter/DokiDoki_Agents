import os
current_file_path = os.path.abspath(__file__)
current_file_dir = os.path.dirname(current_file_path)
os.chdir(current_file_dir)

import sys
sys.path.append("../../")
sys.path.append("../../../")

from global_methods import *

# from persona.memory_structures.spatial_memory import *
# from persona.memory_structures.associative_memory import *
# from persona.memory_structures.scratch import *
# from persona.cognitive_modules.retrieve import *
from persona.prompt_template.run_gpt_prompt import *
from persona.prompt_template.gpt_structure import *


def run_gpt_generate_converse_first(init_persona, target_persona, retrieved, target_relationship):
    def create_prompt_input(init_persona, target_persona, test_input=None):
        if test_input:return test_input
        current_location = '집'
        prompt_input =[]
        prompt_input += [init_persona.scratch.get_sentance_iss()]
        prompt_input += [init_persona.scratch.name]
        prompt_input += [init_persona.scratch.act_description]
        prompt_input += [retrieved]
        prompt_input += [target_relationship]
        prompt_input += [target_persona.scratch.name]
        prompt_input += [target_persona.scratch.act_description]
        prompt_input += [current_location]
        past_convo_summarize = ""
        for i, v in init_persona.a_mem.id_to_node.items():
            if v.predicate == 'chat with':
                past_convo_summarize= v.description
                break
        if past_convo_summarize == None:
            past_convo_summarize='There is no previous conversation history'
        prompt_input += [past_convo_summarize]
        prompt_input += [init_persona.a_mem.curr_chat]
        return prompt_input
    

    gpt_param = {"max_tokens": 1024, "temperature": 0.75, "top_p": 0.9, "top_k":50}
    prompt_input = create_prompt_input(init_persona, target_persona)
    prompt_template = "/home/elicer/main/agent_1111/backend/persona/prompt_template/local/generate_converse_first_v3.txt"
    prompt = generate_prompt(prompt_input, prompt_template)
    print("==============prompt_template==============")
    print(prompt_input) 
    print("==============prompt==============")
    print(prompt)
    # output = 
    output = nonsafe_local_generate_response(prompt, gpt_param)
    print(output)
    data = json.loads(output)

    # uttr과 boolean을 추출

    uttr = list(data.items())[0]  # 첫 번째 항목 (대화)
    boolean = list(data.items())[1][1]
    return uttr, boolean


def run_gpt_generate_converse_second(init_persona, target_persona, retrieved, target_relationship):
    def create_prompt_input(init_persona, target_persona, test_input=None):
        if test_input:return test_input
        current_location = '집'
        prompt_input =[]
        prompt_input += [init_persona.scratch.get_str_iss()]
        prompt_input += [init_persona.scratch.name]
        prompt_input += [init_persona.scratch.act_description]
        prompt_input += [retrieved]
        prompt_input += [target_relationship]
        prompt_input += [target_persona.scratch.name]
        prompt_input += [target_persona.scratch.act_description]
        prompt_input += [current_location]
        past_convo_summarize = ""
        for i, v in init_persona.a_mem.id_to_node.items():
            if v.predicate == 'chat with':
                past_convo_summarize= v.description
                break
        if past_convo_summarize == None:
            past_convo_summarize='There is no previous conversation history'
        prompt_input += [past_convo_summarize]
        prompt_input += [init_persona.a_mem.curr_chat]
        return prompt_input

    gpt_param = {"max_tokens": 1024, "temperature": 0.8, "top_p": 0.9, "top_k":50}
    prompt_input = create_prompt_input(init_persona, target_persona)
    print(prompt_input)
    prompt_template = "/home/elicer/main/agent_1111/backend/persona/prompt_template/local/generate_converse_second_v1.txt"
    prompt = generate_prompt(prompt_input, prompt_template)
    print("==============prompt_template==============")
    print(prompt_input) 
    print("==============prompt==============")
    print(prompt)
    output = nonsafe_local_generate_response(prompt, gpt_param)
    print("==============output==============")
    print(output)
    data = json.loads(output)

    # uttr과 boolean을 추출
    uttr = list(data.items())[0]  # 첫 번째 항목 (대화)
    boolean = list(data.items())[1][1]
 

    return uttr, boolean


def generate_agent_chat_summarize(init_persona, target_persona):
    
    init_persona_curr_chat = init_persona.a_mem.curr_chat
    target_persona_curr_chat = target_persona.a_mem.curr_chat

    chat_summarized = run_gpt_prompt_agent_chat_summarize(init_persona_curr_chat)
    chat_summarize_embedding = get_embedding(chat_summarized)

    embedding_pair= (chat_summarized, chat_summarize_embedding)
    init_persona.a_mem.add_chat_without_thought(init_persona.scaratch.name, 'chat with', target_persona.scratch.name,
                                chat_summarized, embedding_pair, 
                                init_persona_curr_chat)
    target_persona.a_mem.add_chat_without_thought(target_persona.scratch.name, "chat with", init_persona.scaratch.name,
                                chat_summerized, embedding_pair,
                                init_persona_curr_chat)
    init_persona.a_mem.curr_chat = []
    target_persona.a_mem.curr_chat = []


def agent_chat_one_utterance(init_persona, target_persona):
    curr_chat = []
    focal_points = [f"{target_persona.scratch.name}"]
    # retrieved = new_retrieve(init_persona, focal_points, 50)
    retrieved = 'asd'
    target_relationship = init_persona.a_mem.load_relationship(target_persona)
    last_chat = ""
    if init_persona.a_mem.curr_chat == []:
        utt, end = run_gpt_generate_converse_first(init_persona, target_persona, retrieved, target_relationship)
    else:
        utt, end = run_gpt_generate_converse_second(init_persona, target_persona, retrieved, target_relationship)
    
    
    if end:
        init_persona.a_mem.add_curr_chat(utt, end)
        generate_agent_chat_summarize
    init_persona.a_mem.add_curr_chat(utt, end)
    target_persona.a_mem.add_curr_chat(utt, end)

    return init_persona.a_mem.curr_chat


if __name__ == '__main__':
    f = open("local/generate_converse_first_v1.txt", 'r')
    prompt = f.read()
    print(prompt)