"""
출처: https://github.com/joonspk-research/generative_agents/blob/main/reverie/backend_server/persona/cognitive_modules/plan.py

계획을 새우는 모듈
"""
import datetime
import math
import random 
import sys
import time
sys.path.append('../../')

from global_methods import *
from persona.prompt_template.run_gpt_prompt import *
from persona.cognitive_modules.retrieve import *
from persona.cognitive_modules.converse import *

debug = False


def generate_daily_request(persona):
    """
    페르소나의 오늘 할일 생성
    plan과는 다른 오늘의 하루 목표를 만든다고 보면 된다.
    """
    return run_prompt_generate_daily_request(persona, 'local')[0]


def generate_wake_up_hour(persona):
    """
    페르소나가 깨어나는 시간을 생성한다. 이것은 페르소나의 일일 계획을 생성하는 과정에서 중요한 부분이 된다.

    Persona state: identity stable set(정체성 안정 set), lifestyle, first_name

    INPUT:
        persona: 페르소나 클래스 인스턴스
    OUTPUT:
        페르소나가 깨어나는 시간을 나타내는 정수
    EXAMPLE OUTPUT:
        8
    """
    if debug: print("GNS FUNCTION: <generate_wake_up_hour>")
    return int(run_gpt_prompt_wake_up_hour(persona)[0])


def generate_first_daily_plan(persona, wake_up_hour):
    """
    페르소나의 일일 계획을 생성한다.
    기본적으로 하루 동안 이루어지는 장기 계획입니다. 페르소나가 오늘 할 행동의 목록을 반환한다. 일반적으로 다음과 같은 형태로 나타난다.
    '오전 6시에 일어나서 아침 루틴을 완료한다',
    '오전 7시에 아침 식사를 한다',
    행동은 마침표 없이 나온다.

    Persona state: identity stable set(페르소나 정체성), lifestyle, cur_data_str, first_name

    INPUT:
        persona: 페르소나 클래스 인스턴스
        wake_up_hour: 페르소나가 깨어나는 시간을 나타내는 정수(예: 8)
    OUTPUT:
        ['오전 6시에 일어나서 아침 루틴을 완료한다',
        '오전 6시 30분에 아침 식사하고 이를 닦는다',
        '오전 8시부터 오후 12시가지 그림 프로젝트 작업을 한다',
        '오후 12시에 점심을 먹는다',
        '오후 2시부터 오후 4시까지 휴식을 취하고 TV를 본다',
        '오후 4시부터 오후 6시까지 그림 프로젝트 작업을 한다',
        '오후 6시에 저녁을 먹는다', '오후 7시부터 오후 8시까지 TV를 본다']

    """
    if debug: print ("GNS FUNCTION: <generate_first_daily_plan>")
    return run_gpt_prompt_daily_plan(persona, wake_up_hour)[0]


def generate_hourly_schedule(persona, wake_up_hour):
    """
    
    """


def generate_task_decomp(persona, task, duration):
    """
    주어진 작업 설명에 대한 몇 가지 사례로 나누어진 작업 분해

    Persona state: iss 정보, curr_date_str, first_name

    INPUT:
        persona: Persona 클래스
        task: 처리해야 할 작업의 설명을 문자열 형태로 (예: "일어나서 아침 준비")
        duration: 이 작업이 지속되어야 하는 시간을 분 단위로 나타내는 정수 (예:60)
    OUTPUT:
        내부 리스트에 분해된 작업 설명과 작업이 지속되어야 하는 시간이 포함된 리스트의 리스트
    EXAMPLE OUTPUT:
        [['going to the bathroom', 5], ['getting dressed', 5], 
         ['eating breakfast', 15], ['checking her email', 5], 
         ['getting her supplies ready for the day', 15], 
         ['starting to work on her painting', 15]] 
    """
    if debug: print ("GNS FUNCTION: <generate_task_decomp>")
    return run_gpt_prompt_task_decomp(persona, task, duration)[0]

def generate_action_arene(act_desp, persona, maze, act_world, act_sector):
    """
    주어진 페르소나와 작업 설명을 가지고 action_arena를 선택한다.

    Persona state: identity stable set, n-1 day schedule(전날 스케쥴), daily plan(오늘 스케쥴)   

    INPUT:
        act_desp: 새로운 행동의 설명 (예: "수면")
        persona: Persona 클래스 인스턴스
    OUTPUT:
        action_arena (예: "bedroom 2")
    EXAMPLE:
        "bedroom 2"
    """
    # if debug: print ("GNS FUNCTION: <generate_action_arena>")
    return run_gpt_prompt_action_arena(act_desp, persona, maze, act_world, act_sector)[0]


def generate_action_game_object(act_desp, act_address, persona, maze):
    """
    주어진 행동 설명과 act 주소(우리가 행동이 일어날 것으로 예상하는 주소)를 가지고 게임 객체 중 하나를 선택합니다.

    Persona state: identity stable set, n-1 day schedule(전날 스케쥴), daily plan(오늘 스케쥴)

    INPUT:
        act_desp: 새로운 행동의 설명 (예: "수면")
        act_address: 행동이 일어날 장소: 
                    (예: "dolores double studio:double studio:bedroom 2")
        persona: Persona 클래스 인스턴스
    OUTPUT:
        act_game_object
    EXAMPLE:
        "bed"
    """
    # if debug: print ("GNS FUNCTION: <generate_action_game_object>")
    if not persona.s_mem.get_str_accessible_arena_game_objects(act_address):
        # 주어진 주소에서 사용 가능한 게임 객체가 없으면 <random>을 반환
        # 그러면 execute에서 랜덤한 위치로 이동
        return "<random>"
    return run_gpt_prompt_action_game_object(act_desp, persona, maze, act_address)[0]


# def generate_action_pronunciatio(act_desp, persona): 

#     return convo, convo_length

def generate_action_event_triple(act_desp_, persona):

    """
    INPUT:
        act_desp: the description of the action (예: "sleeping")
        persona: 페르소나 클래스 인스턴스
    OUTPUT:
        
    """
    if debug: print ("GNS FUNCTION: <generate_action_event_triple>")
    return run_gpt_prompt_event_triple(act_desp, persona)[0]


# def generate_act_obj_desc(act_game_object, act_desp, persona): 

#     return act_game_object, act_desp

# def generate_act_obj_event_triple(act_game_object, act_obj_desc, persona): 

#     return act_game_object, act_obj_desc

# 대화 생성
# def generate_convo(maze, init_persona, target_persona):

#     # 현재 맵과 페르소나를 넣고 대화를 생성한다.
#     # 나온 아웃풋 값은 [[발화자: 내용], [발화자: 내용]]의 2차원 리스트이다.
#     convo = agent_chat_v2(maze, init_persona, target_persona):
#     all_utt = ""

#     # 대화를 하나씩 아웃풋
#     for row in convo:
#         # 발화자
#         speaker = row[0]
#         # 발화 내용
#         utt = row[1]
#         # 해당 나용을 발화자: 발화 내용 으로 추가
#         all_utt += f"{speaker}: {utt}\n"

#     # 모든 발화 내용을 문자열 길이를 8로 나눈 후 int를 통해 정수로 변환
#     # 나눈 결과를 30으로 나눈다.
#     # math.ceil를 통해 반올림
#     # 이 숫자가 대화 시간을 나타낸다.
#     convo_length = math.ceil(int(len(all_utt)/8)/30)

#     # if debug: print ("GNS FUNCTION: <generate_convo>")
#     # 리스트로된 발화 내용과 발화의 길이를 반환한다
#     return convo, convo_length

# # 발화를 요약한다
# def generate_convo_summary(persona, convo): 
#     # 발화 내용을 요약한다.
#     # 실제 프롬프트 내용은 다음 과 같다.
#     """
#     Conversation: 
#     발화자: 발화 내용
#     발화자: 발화 내용
#     발화자: 발화 내용

#     Summarize the conversation above in one sentence:
#     This is a conversation about

#     ***
#     한국어

#     위의 대화를 한 문장으로 요약하세요:
#     이 대화는 다음에 대한 대화입니다.
#     ***
#     """
#     convo_summary = run_gpt_prompt_summarize_conversation(persona, convo)[0]
#     return convo_summary

# # 대화할지 안 할지를 gpt에 context를 보내서 정하게 한다
# # 현재 코드는 v2를 사용하는데, v1에는 아래의 템플릿에 더해서 답변의 예시가 존재한다. 모델에 따라서는 답변의 예시가 존재하는 v1을 써야할 가능성이 있다.
# def generate_decide_to_talk(init_persona, target_persona, retrieved):
#     # 실제 gpt에 보내는 템플릿은 다음과 같다
#     """
#     Task -- given context, determine whether the subject will initiate a conversation with another. 
#     Format: 
#     Context: []
#     Question: []
#     Reasoning: []
#     Answer in "yes" or "no": []
#     ---
#     Context: !<INPUT 0>! 
#     Right now, it is !<INPUT 1>!. !<INPUT 2>! and !<INPUT 3>! last chatted at !<INPUT 4>! about !<INPUT 5>!. 
#     !<INPUT 6>! 
#     !<INPUT 7>! 

#     Question: Would !<INPUT 8>! initiate a conversation with !<INPUT 9>!? 

#     Reasoning: Let's think step by step.

#     ***
#     한국어

#     작업 -- 주어진 상황에서 주제가 다른 사람과 대화를 시작할지 결정하십시오.
#     형식:
#     상황: []
#     질문: []
#     논리: []
#     "예" 또는 "아니오"로 답하세요: []
#     ---
#     상황: !<입력 0>!
#     지금은 !<입력 1>!입니다. !<입력 2>!와 !<입력 3>!는 마지막으로 !<입력 4>!에 !<입력 5>!에 대해 대화했습니다.
#     !<입력 6>!
#     !<입력 7>!

#     질문: !<입력 8>!가 !<입력 9>!와 대화를 시작할까요?

#     논리: 단계적으로 생각해 봅시다.
#     ***
#     """
#     # 
#     x = run_gpt_prompt_decide_to_talk(init_persona, target_persona, retrieved)[0]
#     # if debug: print ("GNS FUNCTION: <generate_decide_to_talk>")
#     # x 가 "yes" 라면 True 반환. 아니면 False를 반환
#     if x == "yes":
#         return True
#     else:
#         return False
    

# # 해당 함수는 계획에 없단 상황이 벌어졌을 때, 스케쥴을 수정하는 함수
# def generate_new_decomp_schedule(persona, inserted_act, inserted_act_dur, start_hour, end_hour):
#     # 단계 1: 함수의 핵심 변수 설정
#     # <p> 는 현재 우리가 스케줄을 편집하고 있는 페르소나
#     p = persona
#     # <today_min_pass> 는 오늘 지난 시간을 분으로 나타낸다
#     today_min_pass = (int(p.scratch.curr_time.hour) * 60
#                       + int(p.scratch.curr_time.minute) + 1)
#     """
#     단계 2: <main_act_dur>과 <truncated_act_dur>을 생성한다
#     이것들은 기본적으로 페르소나의 부분 요소이다.
#     여기서는 분해에 중점을 둔다

#     <main_act_dur>에 대한 예시는 다음과 같다:
#     ['일어나서 아침 루틴을 완료한다 (오전 6시에 일어남)', 5]
#     ['일어나서 아침 루틴을 완료한다 (오전 6시에 일어남)', 5]
#     ['일어나서 아침 루틴을 완료한다 (화장실을 사용함)', 5]
#     ['일어나서 아침 루틴을 완료한다 (얼굴을 씻음)', 10]
#     ['일어나서 아침 루틴을 완료한다 (침대를 정리함)', 5]
#     ['일어나서 아침 루틴을 완료한다 (아침 식사를 함)', 15]
#     ['일어나서 아침 루틴을 완료한다 (옷을 입음)', 10]
#     ['일어나서 아침 루틴을 완료한다 (집을 떠남)', 5]
#     ['일어나서 아침 루틴을 완료한다 (일을 시작함)', 5]
#     ['하루를 준비한다 (오전 6시에 일어남)', 5]
#     ['하루를 준비한다 (침대를 정리함)', 5]
#     ['하루를 준비한다 (샤워를 함)', 15]
#     ['하루를 준비한다 (옷을 입음)', 5]
#     ['하루를 준비한다 (아침 식사를 함)', 10]
#     ['하루를 준비한다 (치아를 닦음)', 5]
#     ['하루를 준비한다 (커피를 만듦)', 5]
#     ['하루를 준비한다 (이메일을 확인함)', 5]
#     ['하루를 준비한다 (그림 작업을 시작함)', 5]
    
#     그리고 <truncated_act_dur>은 사건이 발생하기까지만 관련된다
    
#     ['일어나서 아침 루틴을 완료한다 (오전 6시에 일어남)', 5]
#     ['일어나서 아침 루틴을 완료한다 (오전 6시에 일어남)', 2]
#     """
#     main_act_dur = []
#     truncated_act_dur = []
#     dur_sum = 0
#     count = 0
#     truncated_fin =False

#     print ("DEBUG::: ", persona.scratch.name)
#     for act, dur in p.scratch.f_daily_schedule:
#         if (dur_sum >= start_hour * 60) and (dur_sum < end_hour * 60):
#             main_act_dur += [[act, dur]]
#             if dur_sum <= today_min_pass:
#                 truncated_act_dur += [[act, dur]]
#             elif dur_sum > today_min_pass and not truncated_fin:
#                 # 마지막 행동, 지속 시간 리스트를 이렇게 넣어야 한다
#                 # 예: ['일어나서 아침 루틴을 완료한다 (일어남...)', 2]
#                 truncated_act_dur += [[p.scratch.f_daily_schedule[count][0],
#                                        dur_sum - today_min_pass]]
#                 truncated_act_dur[-1][-1] -= (dur_sum - today_min_pass)
#                 truncated_fin = True

#         dur_sum += dur
#         count += 1
    
#     persona_name = persona.name
#     main_act_dur = main_act_dur

#     x = truncated_act_dur[-1][0].split("(")[0].strip() + " (on the wat to " + truncated_act_dur[-1][0].split("(")[-1][:-1] + ")"
#     truncated_act_dur[-1][0] = x

#     if "(" in truncated_act_dur[-1][0]:
#         inserted_act = truncated_act_dur[-1][0].split("(")[0].stripp()+ " (" + inserted_act + ")"

#     truncated_act_dur += [[inserted_act, inserted_act_dur]]

#     # 시작 시간과 끝나는 시간을 datetime 객체로 설정합니다.
#     start_time_hour = (datetime.datetime(2022, 10, 31, 0, 0)
#     + datetime.timedelta(hours=start_hour))
#     end_time_hour = (datetime.datetime(2022, 10, 31, 0, 0)
#     + datetime.timedelta(hours=end_hour))
    
#     #디버깅이 활성화되어 있다면, 함수 이름을 출력합니다.
#     # if debug: print ("GNS FUNCTION: <generate_new_decomp_schedule>")
    
#     # 예상치 못한 상황이 벌어졌을 때, 스케줄을 수정하는 함수
#     return run_gpt_prompt_new_decomp_schedule(persona, 
#                                               main_act_dur, 
#                                               truncated_act_dur, 
#                                               start_time_hour,
#                                               end_time_hour,
#                                               inserted_act,
#                                               inserted_act_dur)[0]



# ###############################################################################
# # CHAPTER 3: Plan
# ###############################################################################

# def revise_identity(persona):
#     p_name = persona.scratch.name

#     focal_points = [f"{p_name}' s plan for {persona.scratch.get_str_curr_data_str()}.",
#                     f"Important recent events for {p_name}'s life."]
#     # 현재 페르소나의 focal points(사건 또는 생각)이 주어지면, 각각의 focal points에 대한 노드 집합을 검색 후, 노드 세트를 검색, 이후 사전을 반환하는 함수.
#     retrieved = new_retrieve(persona, focal_points)

#     statements = "[Statements]\n"
#     for key, val in retrieved.items():
#         for i in val:
#             statements += f"{i.created.strftime('%A %B %d -- %H:%M%p')}: {i.embedding_key}\n"

#     # 새로운 검색에서 statements를 가져온다.
#     # statements를 기준으로 프롬프트를 작성.

#     # print (";adjhfno;asdjao;idfjo;af", p_name)
#     plan_prompt = statements + "\n"
#     plan_prompt += f"Given the statements above, is there anything that {p_name} should remember as they plan for"
#     plan_prompt += f" *{persona.scratch.curr_time.strftime()} "
#     plan_prompt += f"If there is any scheduling information, be as specific as possible (include date, time, and location if stated in the statement)\n\n"
#     plan_prompt += f"Write the response from {p_name}'s perspective."
#     plan_note = ChatGPT_single_request(plan_prompt)

#     # 위 프롬프트의 예시는 다음과 같다.

#     '''
#     Statement1
#     Statement2

#     Given the statements above, is there anything that Isabella should remember as they plan for Tuesday February 14 -- 00:02AM If there is any scheduling information, be as specific as possible (include date, time, and location if stated in the statement)

#     Write the response from Isabella's perspective.

#     ***
#     한국어

#     진술1
#     진술2

#     위의 진술들을 고려했을 때, 이사벨라가 2월 14일 화요일 -- 오전 12:02에 계획을 세울 때 기억해야 할 것이 있을까요? 만약 일정 정보가 있다면, 가능한 한 구체적으로 알려주세요 (진술에서 날짜, 시간, 장소가 명시되어 있다면 포함시켜주세요).

#     이사벨라의 관점에서 응답을 작성하세요.
#     ***
#     '''


#     thought_prompt = statements + "\n"
#     thought_prompt += f"Given the statements above, how might we summarize {p_name}'s feelings about their days up to now?\n\n"
#     thought_prompt += f"Write the response from {p_name}'s perspective."
#     thought_note = ChatGPT_single_request(thought_prompt)

#     # 위 코드의 예시는 다음과 같다

#     """
#     statements1
#     statements2
#     Given the statements above, how might we summarize Isabella's feelings about their days up to now?

#     Write the response from Isabella's perspective.

    
#     한국어

#     진술1
#     진술2

#     위의 진술들을 고려했ㅇ르 때, 지금까지 날들에 대한 이사벨라의 감정을 어떻게 요약할 수 있을까요?

#     이사벨라의 관점에서 응답을 작성하세요.
#     """

#     # print (thought_note)

#     # %A: 요일의 전체 이름 (예: Monday, Tuesday)
#     # %B: 월의 전체 이름 (예: January, February)
#     # %d: 일 (01, 02, ... , 31)
#     # %H: 24시간제 시간 (00, 01, ... , 23)
#     # %M: 분 (00, 01, ... , 59)
#     # %p: AM 또는 PM

#     currently_prompt = f"{p_name}'s status from {(persona.scratch.curr_time - datetime.timedelta(days=1)).strftime('%A %B %d')}:\n"
#     currently_prompt += f"{persona.scratch.currently}\n\n"
#     currently_prompt += f"{p_name}'s thoughts at the end of {(persona.scratch.curr_time - datetime.timedelta(days=1)).strftime('%A %B %d')}:\n"
#     currently_prompt += (plan_note + thought_note).replace('\n','') + "\n\n"
#     currently_prompt += f"It is now {persona.scratch.curr_time.strftim('%A %B %d')}. Given the above, write {p_name}'s status for {persona.scratch.curr_time.strftime('%A %B %d')} that reflects {p_name}'s thoughts at the end of {(persona.scratch.curr_time - datetime.timedelta(days=1)).strftime('%A %B %d')}. Write this is third-person talking about {p_name}."
#     currently_prompt += f"If there is any scheduling infromation, be as specific as possible (include date, time, and location if stated in the statement).\n\n"
#     currently_prompt += "Follow this format below:\nStatus: <new status>"
#     new_currently = ChatGPT_single_request(currently_prompt)
#     # 위 프롬프트의 실행 예시는 다음과 같다.
#     """
#     curr_time = February 14, 2023, 00:02:20
    
#     Isabella's status from 요일 월 날짜:
#     Status: 오늘은 그 날입니다! 발렌타인 데이 파티가 드디어 Hobbs Cafe에서 열리게 될 날이죠. Isabella Rodriguez는 이 행사를 위해 지칠 줄 모르고 계획을 준비해 왔습니다. 이제 그 모든 것을 현실로 만들 시간입니다. 파티는 Hobbs Cafe에서 오후 5시에 시작될 예정이며, Isabella는 모든 것이 주의깊게 배열되고 준비되어 모든 이들에게 기억에 남을 저녁을 만들 것이라고 확신하고 있습니다. 그녀는 고객과 친구들을 환영하여 함께 축제를 즐기고 사랑을 축하하길 기다리고 있습니다. Isabella는 그녀의 노력이 결실을 맺을 것이고, 파티가 큰 성공을 거둘 것이라고 확신하고 있습니다.

#     Isabella's thoughts at the end of 요일 월 이전날:
#     앞서 작성했던 plan_note+thought_note

#     It is now 요일 월 날. Given the above, write Isabella's status for 요일 월 날 that reflects's thoughts at the end of 요일 월 이전 날. Write this in third-person talking about Isabella.
#     If there is any scheduling information, be as specific as possible (include date, time, and location if stated in the statement).

#     Follow this format below:
#     Status: <new status>


#     한국어

#     Isabella'의 요일 월 이전 날의 상태:
#     Status: 오늘은 그 날입니다! 발렌타인 데이 파티가 드디어 Hobbs Cafe에서 열리게 될 날이죠. Isabella Rodriguez는 이 행사를 위해 지칠 줄 모르고 계획을 준비해 왓씁니다. 이제 그 모든 것을 현실로 만들 시간입니다. 파티는 Hobbs Cafe에서 오후 5시에 시작될 예정이며, Isabella는 모든 것이 주의깊게 배열되고 준비되어 모든 이들에게 기억에 남을 저녁을 만들 것이라고 확신하고 있습니다. 그녀는 고객과 친구들을 환영하여 함께 축제를 즐기고 사랑을 축하하길 기다리고 있습니다. Isabella는 그녀의 노력이 결실을 맺을 것이고, 파티가 큰 성공을 거둘 것이라고 확신하고 있습니다.

#     Isabella's thoughts at the end of 요일 월 이전날:
#     앞서 작성했던 plan_note+thought_note

#     지금은 요일 월 날짜입니다. 위의 내용을 고려할 때, 이사벨라의 요일 월 이전 날 끝에 대한 생각을 반영하는 이사벨라의 요일 월 날짜에 대한 상태를 작성하세요. 이사벨라에 대해 제3자 시점으로 작성해 주세요.
#     만약 일정 정보가 있다면 가능한 한 구체적으로 작성해 주세요(문장에 날짜, 시간, 위치가 명시되어 있다면 포함시켜 주세요).

#     아래의 형식을 따라 작성해 주세요:
#     상태: <새로운 상태>
#     """

#     # gpt의 답변을 currently에 저장
#     # 이후 새롭게 나온 daily_req_prompt 를 기준으로 다시 하루 일정을 정리하는 daily_plan_req를 만든다.
#     persona.scratch.currently = new_currently
#     daily_req_prompt = persona.scratch.get_str_iss() + "\n"
#     daily_req_prompt += f"Today is {persona.scratch.curr_time.strftime('%A %B %d')}. Here is {persona.scratch.name}'s plan today in broad-strokes (with the time of the day. e.g., have a lunch at 12:00 pm, watch TV from 7 to 8 pm).\n\n"
#     daily_req_prompt += f"Follow this format (the list should have 4~6 items but no more):\n"
#     daily_req_prompt += f"1. wake up and complete the morning routine at <time>, 2. ..."



#     new_daily_req = ChatGPT_single_request(daily_req_prompt)
#     new_daily_req = new_daily_req.replace('\n', ' ')
#     print ("WE ARE HERE!!!", new_daily_req)
#     persona.scratch.daily_plan_req = new_daily_req

# def _long_term_planning(persona, new_day):
#     """
#     새로운 날이 시작될 경우 페르소나의 일일 장기 계획을 수립한다.
#     """

#     # 페르소나는 깨어있는 시간을 생성한다.
#     wake_up_hour = generate_wake_up_hour(persona)

#     # 새로운 날일 경우, 페르소나의 daily_req를 생성한다.
#     # daily_req는 페르소나의 하루를 대략적으로 설명하는 문자열의 목록입니다.

#     if new_day == "First day":
#         # 생성의 시작에 대한 일일 계획을 부트스트래핑합니다:
#         # 이것이 생성의 시작이라면(즉, 이전 날의 일일 요구사항이 없거나), 또는 새로운 날이라면, 새로운 일일 요구사항 세트를 생성하려고 합니다.
#         persona.scratch.daily_req = generate_first_daily_plan(persona,
#                                                               wake_up_hour)

#     elif new_day == "New day":
#         revise_identity(persona)
#         persona.scratch.daily_req = persona.scratch.daily_req

#     persona.scratch.f_daily_schedule =generate_hourly_schedule(persona, wake_up_hour)
#     persona.scratch.f_daily_schedule_hourly_org = (persona.scratch.f_daily_schedule[:])

#     thought = f"This is {persona.scratch.name}'s plan for {persona.scratch.curr_time.strftime('%A %B %d')}:"
#     for i in persona.scratch.daily_req: 
#         thought += f" {i},"
#     thought = thought[:-1] + "."
#     created = persona.scratch.curr_time
#     expiration = persona.scratch.curr_time + datetime.timedelta(days=30)
#     s, p, o = (persona.scratch.name, "plan", persona.scratch.curr_time.strftime('%A %B %d'))
#     keywords = set(["plan"])
#     thought_poignancy = 5
#     thought_embedding_pair = (thought, get_embedding(thought))
#     persona.a_mem.add_thought(created, expiration, s, p, o, 
#                             thought, keywords, thought_poignancy, 
#                             thought_embedding_pair, None)
# # 
# def _determine_action(persona, maze):
    
#     # 현재 내가 하고 있는 시간을 불러온다
#     curr_index = persona.scratch.get_f_daily_schedule_index()
#     # 1시간 뒤에 가져온다
#     curr_index_60 = persona.scratch.get_f_daily_schedule_index(advance=60)
    

#     if curr_index == 0:
#         # 현재 하고 있는 일의 act_description과 duration을 반환
#         act_desp, act_dura = persona.scratch.f_daily_schedule[curr_index]

#         if act_dura >= 60: 

            
# def _choose_retrieved():

#     return

# def _should_react(persona, retrieved, personas):
#     """
#     이 함수는 검색된 값들을 기반으로 페르소나가 어떤 형태의 반응을 보여야 하는지 결정합니다.
    
#     INPUT:
#         persona: 우리가 행동을 결정하고 있는 현재의 <Persona> 인스턴스 입니다.
#         retrieved: 페르소나의 연관 메모리에서 검색된 <ConceptNode>의 딕셔너리입니다. 이 딕셔너리는 다음과 같은 형식을 가집니다:
#         dictionary[event.description] = 
#             {["curr_event"] = <ConceptNode>, 
#             ["events"] = [<ConceptNode>, ...], 
#             ["thoughts"] = [<ConceptNode>, ...] }

#         personas: 모든 페르소나 이름을 키로, <Persona> 인스턴스를 값으로 가지는 딕셔너리.

    
#     페르소나의 반응을 결정한다.
#     """
#     # 대화 시작
#     def lets_talk(init_persona, target_persona, retrieved):
#         # 페르소나의 act_address가 없으면 False
#         if (not target_persona.scratch.act_address
#             or not target_persona.scratch.act_description
#             or not init_persona.scratch.act_address
#             or not init_persona.scratch.act_description):
#             return False
        
#         # 페르소나의 act_description이 존재해도 sleeping 라면 False
#         if ("sleeping" in target_persona.scratch.act_description
#             or "sleeping" in init_persona.scracthc.act_description):
#             return False
        
#         # init_persona의 현재 시간이 23이라면 False
#         if init_persona.scratch.curr_time.hour == 23:
#             return False
        
#         # target_persona의 act_address에 <waiting> 이 존재하면 False
#         if "<waiting>" in target_persona.scratch.act_address:
#             return False
        
#         # 페르소나가 chatting_with 가 값이 존재하면 False
#         if (target_persona.scratch.chatting_with
#             or init_persona.scratch.chatting_with):
#             return False
        
#         # chatting_with_buffer의 값이 존재하고
#         # chatting_with_buffer의 값이 0보다 크면 False
#         if (target_persona.name in init_persona.scratch.chatting_with_buffer):
#             if init_persona.scratch.chatting_with_buffer[target_persona.name] > 0:
#                 return False
        
#         # gpt에 해당 페르소나와 타겟 페르소나가 대화할지 말지를 결정
#         # True 라면 True를 반환
#         if generate_decide_to_talk(init_persona, target_persona, retrieved):
#             return True
        
#         return False
    

#     def lets_react(init_persona, target_persona, retrieved):

#         # 청자의 act_address가 없고
#         # 청자의 act_description이 없고
#         # 화자의 act_address가 없고
#         # 화자의 act_description이 없으면 수행
#         # False를 반환
#         if (not target_persona.scratch.act_address
#             or not target_persona.scratch.act_description
#             or not init_persona.scratch.act_address
#             or not init_persona.scratch.act_description):
#             return False
        
#         if ("sleeping" in target_persona.scratch.act_descriptin
#             or "sleeping" in init_persona.scratch.act_description):
#             return False

#         if init_persona.scratch.curr_time.hour == 23:
#             return False
        
#         if "waiting" in target_persona.scratch.act_description:
#             return False
#         if init_persona.scratch.planned_path == []:
#             return False
        
#         if (init_persona.scratch.act_address
#             != target_persona.scratch.act_address):
#             return False
        
#         react_mode = generate_decide_to_react(init_persona,
#                                               target_persona, retrieved)
        

#         if react_mode == "1":
#             wait_until = ((target_persona.scratch.act_start_time
#                            + datetime.timedelta(minutes=target_persona.scratch.act_duration - 1)).strftime("%B %d, %Y, %H:%M:%S"))
#             return f"wait: {wait_until}"
        
#         elif react_mode =="2":
#             return False
#         else:
#             return False #"keep" 
        
#     if persona.scratch.chatting_with:
#         return False
#     if "<waiting>" in persona.scratch.act_address:
#         return False
    
#     curr_event = retrieved["curr_event"]

#     if ":" not in curr_event.subject:

#         if lets_talk(persona, personas[curr_event.subject], retrieved):
#             return f"chat with {curr_event.subject}"

#     return

# # 이 함수는 입력에 해당하는 값들을 scratch에 해당하는 부분을 새롭게 갱신하는 함수
# def _create_react(persona, inserted_act, inserted_act_dur,
#                   act_address, act_event, chatting_with, chat, chatting_with_buffer,
#                   chatting_end_time, 
#                   act_pronunciatio, act_obj_description, act_obj_pronunciatio, 
#                   act_obj_event, act_start_time=None):
    
#     """
#     persona: 페르소나
#     inserted_act: 입력 액션
#     inserted_act_dur: 걸리는 분
#     act_address: 액션 내용
#     act_even: 액션 이벤트
#     """
#     p = persona

#     min_sum = 0
#     # f_daily_schedule_hourly_org: 페르소나의 시간 단위 계획. 걸리는 시간을 나타내는 두 번째 요소가 값의 단위는 분이긴 하나, 60, 120 과 같이 시간 단위로 쪼개져있다.

#     # get_f_daily_schedule_hourly_org_index 메서드는 현재 하고 있는 작업이 f_daily_schedule_hourly_org 중에서 몇 번째인지를 반환한다.

#     # 입력값은 추가로 내가 미래의 테스크를 확인할 인자인 advance가 존재하나, 없다면 persona.scratch.curr_time 을 가져와서 수행.

#     # 해당 횟수 만큼 for문을 돈다
#     # f_daily_schedule_hourly_org의 형태는 [하는 일, 시간 분] 의 형태이다.
#     # 따라서, min_sum 에는 시간 분에 해당하는 숫자들을 가져와서 더하게 된다.
#     for i in range(p.scratch.get_f_daily_schedule_hourly_org_index()):
#         min_sum += p.scratch.f_daily_schedule_hourly_org[i][1]
#     # min_sum을 60으로 나눠서 시작 시간을 나타낸다
#     start_hour = int (min_sum/60)

#     # f_daily_schedule_hourly_org에서 해당 작업의 걸리는 시간, 분이 120보다 크다면 수행
#     # start_hour에서 걸린 시간 만큼을 더해서 end_hour를 구한다.
#     if (p.scratch.f_daily_schedule_hourly_org
#         [p.scratch.get_f_daily_schedule_hourly_org_index()][1] >= 120):
#         end_hour = start_hour + p.scratch.f_daily_schedule_hourly_org
#         [p.scratch.get_f_daily_schedule_hourly_org_index()][1]/60

#     # 현재 하는 작업의 분+ 다음 작업의 분을 더 했을 때 값이 존재한다면 수행
#     # 끝나는 시간인 end_hour 는 앞서 만들었던 start_hour + 현재 작업의 걸리는 시간+다음 작업의 걸리는 시간
#     elif (p.scratch.f_daily_schedule_hourly_org
#           [p.scratch.get_f_daily_schedule_hourly_org_index()][1] +
#           p.scratch.f_daily_schedule_hourly_org[p.scratch.get_f_daily_schedule_hourly_org_index()+1][1]):
#         end_hour = start_hour + ((p.scratch.f_daily_schedule_hourly_org
#                                   [p.scratch.get_f_daily_schedule_hourly_org_index()][1] + p.scratch.f_daily_schedule_hourly_org
#                                   [p.scratch.get_f_daily_schedule_hourly_org_index()+1][1])/60)
#     # 둘 다 아니라면 start_hour 에 2를 더한다
#     else:
#         end_hour = start_hour + 2
#     # end_hour 출력
#     end_hour = int(end_hour)

#     dur_sum = 0
#     count = 0
#     start_index = None
#     end_index = None
#     # f_daily_schedule을 순회 한다.
#     # 순회를 마치면 start_index 에는 시작 하는 테스크의 index가, end_index에는 끝나는 작업의 index가 들어가게 된다.
#     for act, dur in p.scratch.f_daily_schedule:
#         # 시간을 다 더한 값, dur_sum이 start_hour에 60을 곱한 값 보다 크고 start_index가 None이면 수행
#         # count를 start_index에 넣는다.
#         if dur_sum >= start_hour * 60 and start_index == None:
#             start_index = count
#         # 시간을 다 더한 값, dur_sum이 start_hour에 60을 곱한 값 보다 크고 end_index가 None이면 수행
#         # end_index에 count를 넣는다.
#         if dur_sum >= end_hour * 60 and end_index == None:
#             end_index = count
#         # 크지 않다면 dur, f_daily_schedule에 있는 해당 작업의 분을 계속해서 추가
#         dur_sum += dur
#         # 동시에 count 도 추가
#         count += 1
    
#     # 해당 결과를 토대로 generate_new_decomp_schedule 함수 수행. ret로 반환
#     # generate_new_decomp_schedule 는 계획에 없던 일이 벌어져서 게획을 수정할 때 사용한다.
#     # output 으로 나오는 값은 새롭게 수정된 계획
#     ret = generate_new_decomp_schedule(p, inserted_act, inserted_act_dur, 
#                                        start_hour, end_hour)
    
#     # 페르소나의 f_daily_schedule 중 해당하는 값을 ret로 수정
#     p.scratch.f_daily_schedule[start_index:end_index] = ret
#     # add_new_action 메서드는 입력으로 들어온 키에 해당했던 값을 새롭게 갱신하는 역할을 한다.
#     # 이 메서드로 scratch의 act_address, inserted_act_dur, inserted_act 등등이 바뀐다.
#     p.scratch.add_new_action(act_address,
#                             inserted_act_dur,
#                             inserted_act,
#                             act_pronunciatio,
#                             act_event,
#                             chatting_with,
#                             chat,
#                             chatting_with_buffer,
#                             chatting_end_time,
#                             act_obj_description,
#                             act_obj_pronunciatio,
#                             act_obj_event,
#                             act_start_time)

# # reaction_mode 는 _should_react의 출력값
# def _chat_react(maze, persona, focused_event, reaction_mode, personas):

#     # 두개의 페르소나가 있습니다. -- 대화를 시작하는 페르소나, 대상이 되는 페르소나.
#     # 여기에서 페르소나 인스턴스를 가져온다.
#     init_persona = persona
#     target_persona = personas[reaction_mode[9:].strip]
#     curr_personas = [init_persona, target_persona]

#     # 대화를 여기에서 생성
#     # generate_convo는 대화가 있는 리스트와 대화의 총 길이를 반환
#     convo, duration_min = generate_convo(maze, init_persona, target_persona)
#     convo_summary = generate_convo_summary(init_persona, convo)

#     # inserted_act: 대화 요약
#     # inserted_act_dur: 대화를 몇 분동안 할지
#     # 만약 텍스트가 아니라 음성으로 바꾼다면 inserted_act_dur를 바꿔야 된다고 생각
#     inserted_act = convo_summary
#     inserted_act_dur = duration_min

#     # 액션 시작 시간을 가져온다.
#     act_start_time = target_persona.scratch.act_start_time

#     # 현재 시간을 가져온다.
#     curr_time = target_persona.scratch.curr_time
#     # 현재 시간의 초 부분이 0인지 확인한다.
#     if curr_time.second != 0:
#         # 만약 초가 0이 아니라면 0으로 만들기 위해 연산. 만약 초가 0분 45초 라면 15초를 더해서 1분 0초로 만든다.
#         # 이것에 inserted_act_dur만큼을 더해서 chatting_end_time을 만든다.
#         temp_curr_time = curr_time + datetime.timedelta(seconds=60 - curr_time)
#         chatting_end_time = temp_curr_time + datetime.timedelta(minutes=inserted_act_dur)
#     else:
#         chatting_end_time = curr_time + datetime.timedelta(minutes=inserted_act_dur)

#     # for 문으로 순회
#     # role 에는 init 혹은 target이 들어간다
#     # init 은 화자, target 은 청자.
#     # p에는 init_persona 혹은 target_persona이 순서대로 들어간다.
#     for role, p in [("init", init_persona), ("target", target_persona)]:
#         # role이 init, 화자 라면 수행
#         if role == "init":
#             # act_address 에 "<persona> 청자이름"
#             act_address = f"<persona> {target_persona.name}"
#             # act_event 에 화자이름, "chat_with", 청자이름
#             act_event = (p.name, "chat with", target_persona.name)
#             # chatting_with 에 청자이름
#             chatting_with = target_persona.name
#             # 채팅 버퍼
#             chatting_with_buffer = {}
#             # 채팅버퍼 중 청자 부분의 값을 800으로 설정
#             chatting_with_buffer[target_persona.name] = 800

#         # role 이 target, 청자라면 수행
#         elif role == "target":
#             act_address = f"<persona> {init_persona.name}"
#             act_event = (p.name, "chat with", init_persona.name)
#             chatting_with = init_persona.name
#             chatting_with_buffer = {}
#             chatting_with_buffer[init_persona.name] = 800

#         # 이모지 및 오브젝트 설정                                     
#         act_pronunciatio = "💬" 
#         act_obj_description = None
#         act_obj_pronunciatio = None
#         act_obj_event = (None, None, None)

#         # 행동 생성
#         _create_react(p, inserted_act, inserted_act_dur,
#         act_address, act_event, chatting_with, convo, chatting_with_buffer, chatting_end_time,
#         act_pronunciatio, act_obj_description, act_obj_pronunciatio, 
#         act_obj_event, act_start_time)
            

# def _wait_react(persona, reaction_mode):
#     # 페르소나 설정
#     p = persona

#     # 페르소나의 현재 활동 설명을 가져와서 대기 중인 활동으로 메시지를 설정
#     inserted_act = f'waiting to start {p.scratch.act_description.split("(")[-1][:-1]}'

#     # reaction_mode로부터 종료 시간을 가져옴
#     end_time = datetime.datetime.strptime(reaction_mode[6:].strip(), "%B %d, %Y, %H:%M:%S")

#     # 종료 시간과 페르소나의 현재 시간 사이의 차이(분)을 계산하여 활동 지속 시간을 설정
#     inserted_act_dur = (end_time.minute + end_time.hour * 60) - (p.scratch.curr_time.minute + p.scratch.curr_time.hour * 60) + 1

#     # 페르소나의 현재 위치를 활동 주소로 설정
#     act_address = f"<waiting> {p.scratch.curr_tile[0]} {p.scratch.curr_tile[1]}"

#     # 활동 이벤트 설정
#     act_event = (p.name, "waiting to start", 
#                 p.scratch.act_description.split("(")[-1][:-1])

#     # 대화 관련 변수 초기화
#     chatting_with = None
#     chat = None
#     chatting_with_buffer = None
#     chatting_end_time = None

#     # 활동 아이콘 설정
#     act_pronunciatio = "⌛"

#     # 활동과 관련된 객체 설명 및 아이콘 초기화
#     act_obj_description = None
#     act_obj_pronunciatio = None
#     act_obj_event = (None, None, None)

#     # 활동을 생성하는 함수 호출
#     _create_react(p, inserted_act, inserted_act_dur,
#                 act_address, act_event, chatting_with, chat,
#                 chatting_with_buffer, chatting_end_time,
#                 act_pronunciatio, act_obj_description, act_obj_pronunciatio,
#                 act_obj_event)
    

# def plan(persona, maze, persoans, new_day, retrieved):
#     """
#     체인의 주요 인지 기능. 이 함수는 검색된 메모리와 인식, maze와 첫 날의 상태를 사용하여, 페르소나의 장기 및 단기 계획을 수립한다.

#     INPUT:
#         maze: 현재 세계의 <Maze> 인스턴스
#         personas: 모든 페르소나의 이름을 키로, 페르소나 인스턴스를 값으로 가진 사전
#         new_day: 세 가지 값 중 하나를 가질 수 있다.
#             1)<Boolean> False -- "새로운 날" 주기가 아니다.(만약 그렇다면, 페르소나에 대한 장기 계획 순서를 호출해야 한다)
#             2) <String> "First day" -- 시뮬레이션의 시작이므로 새로운 날이기도 하고 첫 날이기도 합니다.
#             3) <String> "New day" -- 새로운 날입니다.
#         retrieved: 사전의 사전. 첫 번째 레이어는 이벤트를 지정하고, 두 번째 레이어는 관련된 "curr_event", "events", "thoughts"를 지정한다.
#     OUTPUT:
#         페르소나의 목표 액션 주소(persona.scratch.act_address)
#     """
#     # PART 1: 시간별 일정을 생성한다.
#     if new_day:
#         _long_term_planning(persona, new_day)

#     # PART 2: 현재 액션이 만료되었다면, 새로운 계획을 생성하고자 합니다.
#     if persona.scratch.act_check_finished():
#         _determine_action(persona, maze)

#     # PART 3: 응답해야 할 이벤트를 인지했다면(다른 페르소나를 보았다면), 관련 정보를 검색한다.

#     # step 1: 검색된 내용에는 여러 이벤트가 표현될 수 있다. 여기서의 첫 번째 작업은 페르소나에게 초점을 맞출 이벤트를 결정하는 것이다.
#     # <focused_event>는 이와 같은 딕셔너리 형태이다
#     #         dictionary {["curr_event"] = <ConceptNode>, 
#     #                     ["events"] = [<ConceptNode>, ...], 
#     #                     ["thoughts"] = [<ConceptNode>, ...]}
#     focused_event = False
#     if retrieved.keys():
#         focused_event = _choose_retrieved(persona, retrieved)

#     # step 2: 이벤트를 선택한 후에는 페르소나가 인지한 이벤트에 대해 어떤 행동을 취할지 결정해야한다. _should_react에 의해 반환되는 반응 모드는 세 가지가 있다.
#     # a) "chat with" {target_persona.name}
#     # b) "react"
#     # c) False  

#     if focused_event:
#         reaction_mode = _should_react(persona, focused_event, personas)
#         if reaction_mode:
#             # 만약 대화를 원한다면 대화를 생성한다
#             if reaction_mode[:9] == "chat with":
#                 _chat_react(maze, persona, focused_event, reaction_mode, personas)
#             elif reaction_mode[:4] == "wait":
#                 _wait_react(persona, reaction_mode)
    
#     # step 3: 대화 관련 상태 정리
#     # 페르소나가 누가와도 대화하지 않는 경우 여기서 대화 관련 상태를 정리한다
#     if persona.scratch.act_event[1] != "chat with":
#         persona.scratch.chatting_with = None
#         persona.scratch.chat = None

#     # 페르소나가 무한히 서로 대화하는 것을 방지하기 위해서, chatting_with_buffer 는 한 번 대화한 후 같은 대상과 즉시 대화를 재개하지 않도록 하는 버퍼 역할을 합니다. 여기서 버퍼 값의 추적을 유지합니다.
#     curr_persona_chat_buffer = persona.scratch.chatting_with_buffer
#     for persona_name, buffer_count in curr_persona_chat_buffer.items():
#         if persona_name != persona.scratch.chatting_with:
#             persona.scratch.chatting_with_buffer[persona_name] -= 1

#     return persona.scratch.act_address