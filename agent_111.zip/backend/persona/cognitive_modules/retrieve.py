"""
출처: https://github.com/joonspk-research/generative_agents/blob/main/reverie/backend_server/persona/cognitive_modules/retrieve.py

검색 모듈
"""


import sys
sys.path.append('../../')

from global_methods import *
from persona.prompt_template.gpt_structure import *

from numpy import dot
from numpy.linalg import norm


def retrieve(persona, perceived):
    """
    이 함수는 페르소나가 인지하는 이벤트들을 입력으로 받아 페르소나가 계획을 세울 때 고려해야 할 관련된 이벤트와 생각들의 집합을 반환합니다.

    INPUT:
        perceived: 페르소나 주변에서 일어나고 있는 어떤 이벤트들을 대표하는 <ConcptNode>의 이벤트 목록입니다. 여기에 포함된 것은 att_bandwidth와 retention 하이퍼 파라미터에 의해 제어됩니다.
    OUTPUT:
        retrieved: 딕셔너리의 딕셔너리입니다. 첫 번째 계층은 이벤트를 지정하고 두 번째 계층은 관련된 "curr_event", "events", "thoughts"를 지정합닌다.
    """
    # 이벤트와 생각을 따로 분리하여 저장

    retrieved = dict()
    for event in perceived: 
        retrieved[event.description] = dict()
        retrieved[event.description]["curr_event"] = event
        
        relevant_events = persona.a_mem.retrieve_relevant_events(
                            event.subject, event.predicate, event.object)
        retrieved[event.description]["events"] = list(relevant_events)

        relevant_thoughts = persona.a_mem.retrieve_relevant_thoughts(
                            event.subject, event.predicate, event.object)
        retrieved[event.description]["thoughts"] = list(relevant_thoughts)
        
    return retrieved


def cos_sim(a, b): 
    '''
    [신누리]
    1차원 리스트형식의 오브젝트 a와 b를 받아서, 두 벡터 a, b간의 코사인 유사도를 계산하여 반환.
    
    [INPUT] 
    a : 1차원 리스트 형식 오브젝트
    b : 1차원 리스트 형식 오브젝트
    
    [OUTPUT]
    크기만 존재하는 스칼라 값이 반환됩니다.
    -----
    Example input: 
        a = [0.3, 0.2, 0.5]
        b = [0.2, 0.2, 0.5]
    output:
        0.9883693657685838
    '''
    """
    This function calculates the cosine similarity between two input vectors 
    'a' and 'b'. Cosine similarity is a measure of similarity between two 
    non-zero vectors of an inner product space that measures the cosine 
    of the angle between them.

    INPUT: 
        a: 1-D array object 
        b: 1-D array object 
    OUTPUT: 
        A scalar value representing the cosine similarity between the input 
        vectors 'a' and 'b'.
    
    Example input: 
        a = [0.3, 0.2, 0.5]
        b = [0.2, 0.2, 0.5]
    """
    return dot(a, b)/(norm(a)*norm(b))


def normalize_dict_floats(d, target_min, target_max):
    """
      -----
    This function normalizes the float values of a given dictionary 'd' between 
    a target minimum and maximum value. The normalization is done by scaling the
    values to the target range while maintaining the same relative proportions 
    between the original values.

    INPUT: 
        d: Dictionary. The input dictionary whose float values need to be 
        normalized.
        target_min: Integer or float. The minimum value to which the original 
                    values should be scaled.
        target_max: Integer or float. The maximum value to which the original 
                    values should be scaled.
    OUTPUT: 
        d: A new dictionary with the same keys as the input but with the float
        values normalized between the target_min and target_max.

    Example input: 
        d = {'a':1.2,'b':3.4,'c':5.6,'d':7.8}
        target_min = -5
        target_max = 5
    output:
        {'a': -5.0, 'b': -1.6666666666666665, 'c': 1.666666666666666, 'd': 5.0}
    """
    min_val = min(val for val in d.values())
    max_val = max(val for val in d.values())
    range_val = max_val - min_val

    if range_val == 0: 
        for key, val in d.items(): 
            d[key] = (target_max - target_min)/2
    else: 
        for key, val in d.items():
            d[key] = ((val - min_val) * (target_max - target_min) 
                        / range_val + target_min)
    return d



def top_highest_x_values(d, x):
    """
    이 함수는 사전 'd'와 정수 'x'를 입력으로 받아, 가장 값이 높은 상위 'x'개의 키-값 쌍을 포함하는 새로운 사전을 반환합니다.

    입력:
    d: 사전. 가장 값이 높은 상위 'x'개의 키-값 쌍을 추출할 입력 사전입니다.
    x: 정수. 입력 사전에서 추출할 가장 값이 높은 상위 키-값 쌍의 개수입니다.
    출력:
    입력 사전 'd'에서 가장 값이 높은 상위 'x'개의 키-값 쌍을 포함하는 새로운 사전입니다.

    예시 입력:
    d = {'a':1.2,'b':3.4,'c':5.6,'d':7.8}
    x = 3
    """
    sorted_items = sorted(d.items(), key=lambda item: item[1], reverse=True)
    # 상위 'x'개의 항목을 선택하여 새로운 사전을 생성
    top_v = dict(sorted_items[:x])

    return top_v


def extract_recency(persona, nodes):
    """
    현재의 페르소나 객체와 시간 순서대로 정렬된 노드 리스트를 받아 recency_decay 값을 곱해서 recency를 구한다. 최근 일일 수록 recency가 높고 과거의 일일 수록 recency가 낮다

    입력:
    persona: 우리가 회상하는 현재 페르소나.
    nodes: 시간 순서대로 정렬된 노드 객체의 리스트.
    출력:
    recency_out: 키가 node.node_id이고 값이 최신성 점수를 나타내는 실수인 사전.
    """

    # recency_vals = [persona.scratch.recency_decay ** i
    #                 for i in range(1, len(nodes)+1)]
    # recency_out = dict()
    # for count, node in enumerate(nodes):
    #     recency_out[node.node_id] = recency_vals[count]

    # return recency_out
    persona.scratch.recency_decay = 0.995
    recency_vals = [persona.scratch.recency_decay ** i 
                    for i in range(1, len(nodes) + 1)]
    
    recency_out = dict()
    for count, node in enumerate(nodes): 
        recency_out[node.node_id] = recency_vals[count]

    return recency_out



def extract_importance(psrona, nodes):
    """
    현재 페르소나 객체와 시간 순서대로 정렬된 노드 리스트를 받아서 중요도 점수가 계산된 사전을 출력한다.

    입력:
    persona: 회상하고 있는 현재 페르소나.
    nodes: 시간 순서대로 정렬된 노드 객체의 리스트.
    출력:
    importance_out: 키가 node.node_id이고 값이 중요도 점수를 나타내는 실수인 사전.
    """
    importance_out = dict()
    for count, node in enumerate(nodes):
        importance_out[node.node_id] = node.poignancy

    return importance_out


def extract_relevance(persona, nodes, focal_pt):
    """    
    현재 페르소나 객체, 시간 순서대로 정렬된 노드 리스트, 그리고 관심의 초점이 되는 현재 생각이나 사건을 설명하는 focal_pt 문자열을 받아 관련성 점수가 계산된 사전을 출력하는 함수입니다.

    입력:
    persona: 회상하고 있는 현재 페르소나.
    nodes: 시간 순서대로 정렬된 노드 객체의 리스트.
    focal_pt: 현재 생각이나 주목할 사건을 설명하는 문자열.
    출력:
    relevance_out: 키가 node.node_id이고 값이 관련성 점수를 나타내는 실수인 사전.
    """
    focal_embedding = get_embedding(focal_pt)

    relevance_out = dict()
    for count, node in enumerate(nodes):
        node_embedding = persona.a_mem.embeddings[node.embedding_key]
        relevance_out[node.node_id] = cos_sim(node_embedding, focal_embedding)
    return relevance_out

def new_retrieve(persona, focal_points, n_count=30): 
    """
    주어진 현재 페르소나(persona)와 중심점들(focal_points)에 대해, 각 중심점에 대한 노드(node) 집합을 검색하여 딕셔너리를 반환합니다.

    INPUT:
        persona: 우리가 검색할 메모리를 가진 현재 페르소나 객체입니다.
        focal_points: 현재 검색의 중심이 되는 이벤튼나 생각들의 문자열 목록입니다.
    OUTPUT:
        retrieved: 키가 문자열의 중심점이고 값이 에이전트의 연관 메모리에서 노드객체의 목록인 딕셔너리 입니다.

    예시 입력:
        persona = <persona> object
        focal_poins = ["How are you?", "Jane is swimming in the pond"]
    """
    # s_mem: spatial_memory
    # a_mem: associative_memory
    # <retrieved>는 최종 반환되게 되는 기본 사전
    retrieved = dict()
    for focal_pt in focal_points:
        # 에이전트의 메모리에서 모든 노드(생각과 이벤트 모두)를 가져와서
        # 생성된 날짜와 시간으로 정렬
        # 원시 대화 내용도 가져올 수 있으나 지금은 이렇게 한다
        """
        [i.last_accessed, i] 
        리스트 컴프리헨션을 통해 최종적으로 들어가게 될 값 형식. 해당 되는 2개의 원소가 형태가 for 문을 돌 때마다 들어가게 된다.

        for i in persona.a_mem.seq_event + persona.a_mem_.seq_thought
        리스트 컴프리헨션에서 for 문을 돌게 될 대상. associative_memory에서 seq_event에 해당하는 값과 seq_thought에 해당하는 값을 i에 넣어서 순회 한다.

        if "idle" not in i.embedding_key
        순회 할 때, embedding_key에 idle이 없으면 해당 되어 위의 최종 값에 들어가게 된다.

        최종 형식은 [2023-02-13 16:41:10, <__main__.ConceptNode object at 0x00000213444C95D0>]

        와 같은 형식이 된다.
        """
        nodes = [[i.last_accessed, i]
                for i in persona.a_mem.seq_event + persona.a_mem.seq_thought
                if "idle" not in i.embedding_key]

        # nodes = [[i.last_accessed, i]
        #         for i in persona.a_mem.embedding_key]
        # for i in persona.a_mem.id_to_nodes().items()
        # 이렇게 해야 최근 정보가 많은 가중치를 가지는 예시를 따르게 된다.
        nodes = sorted(nodes, key=lambda x: x[0])
        nodes = [i for created, i in nodes]

        # 노드를 최근에 일어난 순으로 정렬
        # 0과 1로 정규화
        recency_out = extract_recency(persona, nodes)
        recency_out = normalize_dict_floats(recency_out, 0, 1)
        
        # 중요한 일
        importance_out = extract_importance(persona, nodes)
        importance_out = normalize_dict_floats(importance_out, 0, 1)

        # 임베딩 점수
        relevance_out = extract_relevance(persona, nodes, focal_pt)
        relevance_out = normalize_dict_floats(relevance_out, 0, 1)

        """
        각 구성 요소의 값을 결합하여 최종 점수를 계산한다.
        master_out에는 가중치가 들어간 최종 점수가 들어가게 된다.
        """
        # gw = [1, 1, 1]
        # gw = [1, 2, 1]
        gw = [0.5, 3, 2]
        master_out = dict()
        # recency_out.keys() 는 노드 이름 목록
        for key in recency_out.keys():
            # 최근 일어난 일에는 0.5의 가중치, 중요하다고 판단되는 일에는 3의 가중치, 유사도에는 2의 가중치를 부여한다.
            master_out[key] = (persona.scratch.recency_w*recency_out[key]*gw[0]
                            + persona.scratch.relevance_w*relevance_out[key]*gw[1]
                            + persona.scratch.importance_w*importance_out[key]*gw[2])
        
        # 값이 높은 순으로 정렬
        master_out = top_highest_x_values(master_out, len(master_out.keys()))
        for key, val in master_out.items():
            print (persona.a_mem.id_to_node[key].embedding_key, val)
            print (persona.scratch.recency_w*recency_out[key]*1, 
                    persona.scratch.relevance_w*relevance_out[key]*1, 
                    persona.scratch.importance_w*importance_out[key]*1)
            
        """
        가장 높은 x 값을 추출한다
        <master_out> 은 node.id의 키와 실수 형태의 값을 가지고 있다. 가장 높은 x 값을 얻으면 node.id를 노드로 변환하여 노드의 리스트를 반환한다
        """
        master_out = top_highest_x_values(master_out, n_count)
        master_nodes = [persona.a_mem.id_to_node[key]
                        for key in list(master_out.keys())]
        
        for n in master_nodes:
            n.last_accessed = persona.scratch.curr_time

        retrieved[focal_pt] = master_nodes
    
    return retrieved