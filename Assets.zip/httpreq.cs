using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Net;
using System.IO;
using UnityEngine.Networking;
using UnityEngine.Rendering.Universal;
using TMPro;
using UnityEditor.ShaderGraph.Internal;	// UnityWebRequest����� ���ؼ� �����ش�.
using System;


[System.Serializable]
public class Execution
{
    public string Sub;
    public string P;
    public string Obj;
    public string location;
    public int duration;
    public string[] chat; // ��ø�� �迭�� �ƴ� �ܼ� ���ڿ� �迭
   
}

[System.Serializable]
public class ReceivedJson
{
    public Execution[] executions;
}
public class httpreq : MonoBehaviour
{
    public event Action<ReceivedJson> OnDataReceived;

    public IEnumerator GetDialogueDataFromServer(string url)
    {
        UnityWebRequest www = UnityWebRequest.Get(url);
        yield return www.SendWebRequest();

        if (www.error == null)
        {
            ReceivedJson data = JsonUtility.FromJson<ReceivedJson>(www.downloadHandler.text);
            OnDataReceived?.Invoke(data);
        }
        else
        {
            Debug.LogError("Error fetching dialogue data: " + www.error);
        }
    }

}


