using System.Collections;
using System.Collections.Generic;
using UnityEngine;

public class NewPlayerController : MonoBehaviour
{
    // Start is called before the first frame update
    void Start()
    {
        
    }

    // Update is called once per frame
    void Update()
    {
        if (Input.GetKey(KeyCode.W))
        {
            GetComponent<Animator>().SetFloat("Speed", 1);
        }
        if (Input.GetKey(KeyCode.D))
        {
            GetComponent<Animator>().SetFloat("Speed", -1);
        }
        if (Input.GetKey(KeyCode.Space))
        {
            GetComponent<Animator>().SetFloat("Speed", 0);
        }
        if (Input.GetKey(KeyCode.S))
        {
        }
        if (Input.GetKey(KeyCode.D))
        {
        }

        GetComponent<CharacterController>().Move(Vector3.down * Time.deltaTime);
    }
}
